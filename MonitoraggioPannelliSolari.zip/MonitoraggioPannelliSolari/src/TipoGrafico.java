
/**
 *
 * @author Leo
 */
public enum TipoGrafico {
    Produzione, Consumi, Immissioni
}
